// I change the code for one of the rat songs from the class mate. I made it to be a race between turte and rabbit with a background song.You can use the mouse of x and y to control the turtle and rabbit.//

let rabbit;
let turtle;

function preload() {
  rabbit = loadImage('rabbit.png');
  turtle = loadImage('turtle.png')
  backgroundmusic = loadSound('race.mp3');
  
  
}

function setup() {
  createCanvas(windowWidth, 800);
  backgroundmusic.loop();
  rabbitAmp = new p5.Amplitude();
  turtleAmp = new p5.Amplitude();
}


function draw() {
  background(220);
  line(windowWidth - 100, 0, windowWidth - 100, windowHeight)
  line(0, 400, windowWidth, 400)
  let volume = map(mouseX, 0, width, 0, 1);
  volume = constrain(volume, 0, 1);
  backgroundmusic.amp(volume);
  
  let rabbitWidth = mouseX - 50;
  let rabbitHeight =50;
  let turtleWidth = mouseY - 50;
  let turtleHeight = 600;
  image(rabbit, rabbitWidth, rabbitHeight, 150, 100);

  image(turtle, turtleWidth, turtleHeight, 150, 150);


 }

